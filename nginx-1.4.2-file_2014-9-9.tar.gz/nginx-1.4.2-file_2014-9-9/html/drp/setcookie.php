<?php  
	header('P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR"');  

	setcookie("userName", $_GET['name'], 0 , "/");  

?>
